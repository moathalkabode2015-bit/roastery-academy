-- PostgreSQL / Supabase starter schema
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'subscriber' check (role in ('owner','subscriber')),
  created_at timestamptz not null default now()
);

create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null
);

create table if not exists recipes (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references categories(id),
  title text not null,
  summary text,
  ingredients jsonb not null default '[]'::jsonb,
  instructions jsonb not null default '[]'::jsonb,
  visibility text not null default 'subscribers' check (visibility in ('public','subscribers','private')),
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists lessons (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  video_url text,
  sort_order int not null default 0,
  visibility text not null default 'subscribers' check (visibility in ('public','subscribers','private')),
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  plan text not null check (plan in ('monthly','yearly')),
  status text not null default 'pending' check (status in ('pending','active','expired','cancelled')),
  starts_at timestamptz,
  ends_at timestamptz,
  provider_reference text,
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table categories enable row level security;
alter table recipes enable row level security;
alter table lessons enable row level security;
alter table subscriptions enable row level security;

-- Starter policies: configure the first owner account securely on the server.
-- Never allow a client to self-assign role='owner'.
create policy "profiles read own" on profiles for select
using (auth.uid() = id);

create policy "categories visible" on categories for select
using (true);

create policy "recipes visible to active subscribers or owner" on recipes for select
using (
  visibility = 'public'
  or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner')
  or (
    visibility = 'subscribers'
    and exists (
      select 1 from subscriptions s
      where s.user_id = auth.uid()
        and s.status = 'active'
        and s.ends_at > now()
    )
  )
);

create policy "lessons visible to active subscribers or owner" on lessons for select
using (
  visibility = 'public'
  or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner')
  or (
    visibility = 'subscribers'
    and exists (
      select 1 from subscriptions s
      where s.user_id = auth.uid()
        and s.status = 'active'
        and s.ends_at > now()
    )
  )
);

create policy "owner manages recipes" on recipes for all
using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner'))
with check (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner'));

create policy "owner manages lessons" on lessons for all
using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner'))
with check (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner'));

create policy "subscriber reads own subscription" on subscriptions for select
using (auth.uid() = user_id or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'owner'));

-- Create a subscriber profile automatically after signup.
-- The role is hard-coded to 'subscriber'; clients cannot choose 'owner'.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', ''), 'subscriber')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: promote the first owner manually from the Supabase SQL Editor
-- only after that account has signed up and its UUID has been verified:
-- update public.profiles set role = 'owner' where id = '<verified-auth-user-uuid>';
-- Never expose this promotion query in the mobile app or a public API.

insert into public.categories (title, slug) values
  ('خلطات القهوة', 'coffee'),
  ('خلطات البهارات', 'spices'),
  ('المكسرات', 'nuts'),
  ('التتبيلات', 'marinades')
on conflict (slug) do nothing;
