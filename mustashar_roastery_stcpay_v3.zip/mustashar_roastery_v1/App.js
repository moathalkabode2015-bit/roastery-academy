import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, TouchableOpacity, ScrollView,
  TextInput, StyleSheet, StatusBar, Alert
} from "react-native";

const GREEN = "#123C2D";
const GOLD = "#D7B66D";
const CREAM = "#F6F4EE";

const categories = [
  { id: "coffee", title: "خلطات القهوة", desc: "القهوة العربية والسعودية", icon: "☕" },
  { id: "spices", title: "خلطات البهارات", desc: "التوابل والخلطات", icon: "🌶️" },
  { id: "nuts", title: "المكسرات", desc: "التحميص والتتبيل", icon: "🥜" },
  { id: "marinades", title: "التتبيلات", desc: "الشواء والدجاج", icon: "🍗" }
];

const lessons = [
  "مبادئ اختيار المواد الخام",
  "أساسيات تركيب الخلطات",
  "توازن النكهات والروائح",
  "طرق الطحن والتجانس",
  "التعبئة والحفظ والجودة"
];

function Header() {
  return (
    <View style={styles.header}>
      <Text style={styles.brand}>مستشار المحامص والمطاحن</Text>
      <Text style={styles.tagline}>تعلم • اكتشف • اصنع خلطاتك باحتراف</Text>
      <Text style={styles.owner}>إعداد وإشراف: أبو أمجد</Text>
    </View>
  );
}

function Tile({ icon, title, desc, onPress }) {
  return (
    <TouchableOpacity style={styles.tile} onPress={onPress} activeOpacity={0.85}>
      <Text style={styles.tileIcon}>{icon}</Text>
      <Text style={styles.tileTitle}>{title}</Text>
      <Text style={styles.tileDesc}>{desc}</Text>
    </TouchableOpacity>
  );
}

export default function App() {
  const [tab, setTab] = useState("home");
  const [category, setCategory] = useState("coffee");
  const [kilos, setKilos] = useState("5");
  const [adminSection, setAdminSection] = useState("recipes");
  const [recipes, setRecipes] = useState([]);
  const [adminLessons, setAdminLessons] = useState(lessons.map((title, i) => ({ id: `lesson-${i}`, title, description: "منهج تدريبي مقترح", videoUrl: "" })));
  const [editingRecipe, setEditingRecipe] = useState(null);
  const [recipeTitle, setRecipeTitle] = useState("");
  const [recipeCategory, setRecipeCategory] = useState("coffee");
  const [recipeSummary, setRecipeSummary] = useState("");
  const [recipeIngredients, setRecipeIngredients] = useState("");
  const [recipeSteps, setRecipeSteps] = useState("");
  const [lessonTitle, setLessonTitle] = useState("");
  const [lessonDescription, setLessonDescription] = useState("");
  const [lessonVideo, setLessonVideo] = useState("");
  const [editingLesson, setEditingLesson] = useState(null);

  const selectedCategory = categories.find(c => c.id === category) || categories[0];
  const multiplier = useMemo(() => Math.max(0, Number(kilos) || 0), [kilos]);

  const showCategory = (id) => {
    setCategory(id);
    setTab("recipes");
  };

  const renderHome = () => (
    <>
      <Text style={styles.sectionTitle}>مرحباً بك في عالم الخلطات</Text>
      <Text style={styles.muted}>مكتبة تعليمية متخصصة لأصحاب المحامص والمطاحن.</Text>
      <View style={styles.grid}>
        {categories.map(c => <Tile key={c.id} {...c} onPress={() => showCategory(c.id)} />)}
      </View>
      <View style={styles.panel}>
        <Text style={styles.panelTitle}>دفتر أسرار أبو أمجد</Text>
        <Text style={styles.muted}>مساحة خاصة للوصفات الاحترافية ونسب المكونات، لا يضيف المحتوى فيها إلا المدير.</Text>
        <TouchableOpacity style={styles.outlineButton} onPress={() => setTab("admin")}>
          <Text style={styles.outlineText}>لوحة المدير</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.panel}>
        <Text style={styles.panelTitle}>ابدأ التعلم</Text>
        <Text style={styles.muted}>دروس تأسيسية في اختيار المواد الخام وتركيب الخلطات وجودة المنتج.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={() => setTab("academy")}>
          <Text style={styles.primaryText}>دخول الأكاديمية</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderRecipes = () => (
    <>
      <Text style={styles.sectionTitle}>مكتبة الخلطات والوصفات</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight: 48 }}>
        {categories.map(c => (
          <TouchableOpacity key={c.id} onPress={() => setCategory(c.id)}
            style={[styles.chip, category === c.id && styles.chipActive]}>
            <Text style={[styles.chipText, category === c.id && styles.chipTextActive]}>{c.title}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.panel}>
        <Text style={styles.eyebrow}>{selectedCategory.title}</Text>
        <Text style={styles.panelTitle}>أساسيات {selectedCategory.title}</Text>
        <Text style={styles.muted}>درس تمهيدي للتعرف على المكونات وخصائصها وطرق اختبار الجودة وتوازن النكهات.</Text>
        <Text style={styles.notice}>سيتم نشر الوصفات التفصيلية والمقادير المعتمدة بواسطة مدير التطبيق فقط.</Text>
      </View>
      {recipes.filter(r => r.category === category).map(item => (
        <View key={item.id} style={styles.panel}>
          <Text style={styles.panelTitle}>{item.title}</Text>
          {!!item.summary && <Text style={styles.muted}>{item.summary}</Text>}
          <Text style={styles.fieldLabel}>المكونات</Text>
          {item.ingredients.map((line, i) => <Text key={i} style={styles.muted}>• {line}</Text>)}
          {!!item.steps.length && <><Text style={styles.fieldLabel}>طريقة التحضير</Text>{item.steps.map((line, i) => <Text key={i} style={styles.muted}>{i + 1}. {line}</Text>)}</>}
        </View>
      ))}
    </>
  );

  const renderAcademy = () => (
    <>
      <Text style={styles.sectionTitle}>أكاديمية المحامص والمطاحن</Text>
      {adminLessons.map((lesson, i) => (
        <View key={lesson.id} style={styles.lesson}>
          <View style={styles.lessonNumber}><Text style={styles.lessonNumberText}>{i + 1}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.lessonTitle}>{lesson.title}</Text>
            <Text style={styles.muted}>{lesson.description || "منهج تدريبي"}</Text>
          </View>
          <Text style={{ fontSize: 20 }}>📘</Text>
        </View>
      ))}
    </>
  );

  const renderCalculator = () => (
    <>
      <Text style={styles.sectionTitle}>حاسبة تحويل المقادير</Text>
      <View style={styles.panel}>
        <Text style={styles.muted}>الوصفة الأصلية محسوبة على أساس 1 كجم. أدخل الوزن المطلوب بالكيلوغرام.</Text>
        <Text style={styles.fieldLabel}>الوزن المطلوب (كجم)</Text>
        <TextInput value={kilos} onChangeText={setKilos} keyboardType="decimal-pad"
          style={styles.input} placeholder="مثال: 5" />
        <Text style={styles.muted}>معامل مضاعفة جميع مكونات الوصفة</Text>
        <Text style={styles.multiplier}>{multiplier.toLocaleString("en-US")}×</Text>
        <Text style={styles.notice}>اضرب وزن كل مكون في هذا المعامل. مثال: 20 جرام × {multiplier} = {(20 * multiplier).toLocaleString("en-US")} جرام.</Text>
      </View>
    </>
  );


  const renderSubscriptions = () => (
    <>
      <Text style={styles.sectionTitle}>باقات الاشتراك</Text>
      <Text style={styles.muted}>اختر الباقة المناسبة للوصول إلى مكتبة الخلطات والدروس التعليمية.</Text>
      <View style={styles.panel}>
        <Text style={styles.panelTitle}>الاشتراك الشهري</Text>
        <Text style={styles.price}>199 ريال سعودي</Text>
        <Text style={styles.muted}>صلاحية الوصول لمدة شهر واحد.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={() => Alert.alert("قريباً", "سيتم تفعيل الدفع الإلكتروني بعد ربط بوابة الدفع.")}>
          <Text style={styles.primaryText}>اشترك شهرياً</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.panel}>
        <Text style={styles.eyebrow}>الأوفر على مدار السنة</Text>
        <Text style={styles.panelTitle}>الاشتراك السنوي</Text>
        <Text style={styles.price}>1,999 ريال سعودي</Text>
        <Text style={styles.muted}>صلاحية الوصول لمدة 12 شهراً.</Text>
        <Text style={styles.notice}>وفر 389 ريال مقارنة بالدفع الشهري لمدة سنة كاملة.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={() => Alert.alert("قريباً", "سيتم تفعيل الدفع الإلكتروني بعد ربط بوابة الدفع.")}>
          <Text style={styles.primaryText}>اشترك سنوياً</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.notice}>الأسعار معتمدة في تصميم النسخة الأولية. الدفع وتجديد الاشتراك غير مفعلين حتى الآن.</Text>
    </>
  );

  const resetRecipeForm = () => {
    setEditingRecipe(null); setRecipeTitle(""); setRecipeCategory("coffee");
    setRecipeSummary(""); setRecipeIngredients(""); setRecipeSteps("");
  };

  const saveRecipe = () => {
    if (!recipeTitle.trim() || !recipeIngredients.trim()) {
      Alert.alert("بيانات ناقصة", "أدخل اسم الوصفة ومكوناتها على الأقل."); return;
    }
    const item = {
      id: editingRecipe?.id || `recipe-${Date.now()}`,
      title: recipeTitle.trim(), category: recipeCategory,
      summary: recipeSummary.trim(),
      ingredients: recipeIngredients.split("\n").map(x => x.trim()).filter(Boolean),
      steps: recipeSteps.split("\n").map(x => x.trim()).filter(Boolean)
    };
    setRecipes(current => editingRecipe ? current.map(x => x.id === item.id ? item : x) : [item, ...current]);
    resetRecipeForm(); setAdminSection("recipes");
    Alert.alert("تم الحفظ", "تم حفظ الوصفة في النسخة التجريبية الحالية.");
  };

  const editRecipe = (item) => {
    setEditingRecipe(item); setRecipeTitle(item.title); setRecipeCategory(item.category);
    setRecipeSummary(item.summary || ""); setRecipeIngredients(item.ingredients.join("\n"));
    setRecipeSteps(item.steps.join("\n")); setAdminSection("recipeForm");
  };

  const saveLesson = () => {
    if (!lessonTitle.trim()) { Alert.alert("بيانات ناقصة", "أدخل عنوان الدرس."); return; }
    const item = { id: editingLesson?.id || `lesson-${Date.now()}`, title: lessonTitle.trim(), description: lessonDescription.trim(), videoUrl: lessonVideo.trim() };
    setAdminLessons(current => editingLesson ? current.map(x => x.id === item.id ? item : x) : [...current, item]);
    setEditingLesson(null); setLessonTitle(""); setLessonDescription(""); setLessonVideo(""); setAdminSection("lessons");
    Alert.alert("تم الحفظ", "تم حفظ الدرس في النسخة التجريبية الحالية.");
  };

  const renderAdmin = () => (
    <>
      <Text style={styles.sectionTitle}>لوحة إدارة المالك</Text>
      <Text style={styles.muted}>إدارة مكتبة المحتوى ومراجعة الاشتراكات — أبو أمجد</Text>
      <View style={styles.adminTabs}>
        {[ ["recipes", "الوصفات"], ["recipeForm", "إضافة وصفة"], ["lessons", "الدروس"], ["lessonForm", "إضافة درس"], ["subs", "الاشتراكات"] ].map(([id, label]) => (
          <TouchableOpacity key={id} onPress={() => { if (id === "recipeForm") resetRecipeForm(); if (id === "lessonForm") { setEditingLesson(null); setLessonTitle(""); setLessonDescription(""); setLessonVideo(""); } setAdminSection(id); }} style={[styles.adminTab, adminSection === id && styles.adminTabActive]}>
            <Text style={[styles.adminTabText, adminSection === id && styles.adminTabTextActive]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {adminSection === "recipes" && <View style={styles.panel}>
        <Text style={styles.panelTitle}>الوصفات المنشورة ({recipes.length})</Text>
        {recipes.length === 0 ? <Text style={styles.muted}>لم تتم إضافة وصفات بعد. ابدأ بإضافة أول وصفة.</Text> : recipes.map(item => (
          <View key={item.id} style={styles.adminItem}>
            <View style={{flex:1}}><Text style={styles.lessonTitle}>{item.title}</Text><Text style={styles.muted}>{categories.find(c=>c.id===item.category)?.title || "قسم عام"} • {item.ingredients.length} مكونات</Text></View>
            <TouchableOpacity onPress={() => editRecipe(item)}><Text style={styles.actionText}>تعديل</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => Alert.alert("حذف الوصفة", `هل تريد حذف «${item.title}»؟`, [{text:"إلغاء",style:"cancel"},{text:"حذف",style:"destructive",onPress:()=>setRecipes(cur=>cur.filter(x=>x.id!==item.id))}])}><Text style={styles.deleteText}>حذف</Text></TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.primaryButton} onPress={() => { resetRecipeForm(); setAdminSection("recipeForm"); }}><Text style={styles.primaryText}>＋ إضافة وصفة جديدة</Text></TouchableOpacity>
      </View>}

      {adminSection === "recipeForm" && <View style={styles.panel}>
        <Text style={styles.panelTitle}>{editingRecipe ? "تعديل الوصفة" : "إضافة وصفة جديدة"}</Text>
        <Text style={styles.fieldLabel}>اسم الوصفة</Text><TextInput value={recipeTitle} onChangeText={setRecipeTitle} style={styles.input} placeholder="مثال: خلطة قهوة عربية خاصة" />
        <Text style={styles.fieldLabel}>التصنيف</Text>
        <View style={styles.categoryChoices}>{categories.map(c=><TouchableOpacity key={c.id} onPress={()=>setRecipeCategory(c.id)} style={[styles.chip,recipeCategory===c.id&&styles.chipActive]}><Text style={[styles.chipText,recipeCategory===c.id&&styles.chipTextActive]}>{c.title}</Text></TouchableOpacity>)}</View>
        <Text style={styles.fieldLabel}>وصف مختصر</Text><TextInput value={recipeSummary} onChangeText={setRecipeSummary} style={styles.input} placeholder="نبذة عن الوصفة" />
        <Text style={styles.fieldLabel}>المكونات — كل مكون في سطر مستقل</Text><TextInput value={recipeIngredients} onChangeText={setRecipeIngredients} multiline style={[styles.input,styles.multiline]} placeholder={'بن مطحون: 800 جرام\nهيل: 150 جرام\nزعفران: 2 جرام'} />
        <Text style={styles.fieldLabel}>طريقة التحضير — كل خطوة في سطر</Text><TextInput value={recipeSteps} onChangeText={setRecipeSteps} multiline style={[styles.input,styles.multiline]} placeholder={'اخلط المكونات جيداً\nاحفظ الخلطة في عبوة محكمة'} />
        <TouchableOpacity style={styles.primaryButton} onPress={saveRecipe}><Text style={styles.primaryText}>حفظ الوصفة</Text></TouchableOpacity>
        <TouchableOpacity style={styles.outlineButton} onPress={()=>{resetRecipeForm();setAdminSection("recipes");}}><Text style={styles.outlineText}>إلغاء</Text></TouchableOpacity>
      </View>}

      {adminSection === "lessons" && <View style={styles.panel}>
        <Text style={styles.panelTitle}>الدروس التعليمية ({adminLessons.length})</Text>
        {adminLessons.map(item=><View key={item.id} style={styles.adminItem}><View style={{flex:1}}><Text style={styles.lessonTitle}>{item.title}</Text><Text style={styles.muted}>{item.description || "بدون وصف"}</Text></View><TouchableOpacity onPress={()=>{setEditingLesson(item);setLessonTitle(item.title);setLessonDescription(item.description||"");setLessonVideo(item.videoUrl||"");setAdminSection("lessonForm");}}><Text style={styles.actionText}>تعديل</Text></TouchableOpacity><TouchableOpacity onPress={()=>Alert.alert("حذف الدرس",`حذف «${item.title}»؟`,[{text:"إلغاء",style:"cancel"},{text:"حذف",style:"destructive",onPress:()=>setAdminLessons(cur=>cur.filter(x=>x.id!==item.id))}])}><Text style={styles.deleteText}>حذف</Text></TouchableOpacity></View>)}
        <TouchableOpacity style={styles.primaryButton} onPress={()=>{setEditingLesson(null);setLessonTitle("");setLessonDescription("");setLessonVideo("");setAdminSection("lessonForm");}}><Text style={styles.primaryText}>＋ إضافة درس</Text></TouchableOpacity>
      </View>}

      {adminSection === "lessonForm" && <View style={styles.panel}>
        <Text style={styles.panelTitle}>{editingLesson ? "تعديل الدرس" : "إضافة درس جديد"}</Text>
        <Text style={styles.fieldLabel}>عنوان الدرس</Text><TextInput value={lessonTitle} onChangeText={setLessonTitle} style={styles.input} placeholder="عنوان الدرس" />
        <Text style={styles.fieldLabel}>وصف الدرس</Text><TextInput value={lessonDescription} onChangeText={setLessonDescription} style={styles.input} placeholder="ماذا سيتعلم المشترك؟" />
        <Text style={styles.fieldLabel}>رابط الفيديو (اختياري)</Text><TextInput value={lessonVideo} onChangeText={setLessonVideo} style={styles.input} placeholder="https://..." autoCapitalize="none" />
        <TouchableOpacity style={styles.primaryButton} onPress={saveLesson}><Text style={styles.primaryText}>حفظ الدرس</Text></TouchableOpacity>
        <TouchableOpacity style={styles.outlineButton} onPress={()=>setAdminSection("lessons")}><Text style={styles.outlineText}>إلغاء</Text></TouchableOpacity>
      </View>}

      {adminSection === "subs" && <View style={styles.panel}>
        <Text style={styles.panelTitle}>إدارة المشتركين والاشتراكات</Text>
        <Text style={styles.muted}>ستظهر هنا طلبات الاشتراك، اسم المشترك، الباقة، تاريخ البداية والانتهاء، وحالة الدفع بعد ربط قاعدة البيانات وبوابة الدفع.</Text>
        <View style={styles.statRow}><View style={styles.statBox}><Text style={styles.statNumber}>199 ر.س</Text><Text style={styles.muted}>شهري</Text></View><View style={styles.statBox}><Text style={styles.statNumber}>1,999 ر.س</Text><Text style={styles.muted}>سنوي</Text></View></View>
        <Text style={styles.notice}>لا يمكن اعتماد دفع أو تفعيل عضوية حقيقية من هذه النسخة المحلية. لا تعرض هذه الشاشة بيانات مشتركين فعلية.</Text>
      </View>}
      <Text style={styles.notice}>مهم: البيانات التي تضيفها الآن محفوظة داخل ذاكرة التطبيق أثناء تشغيله فقط. يلزم ربط Supabase أو خادم آمن وتسجيل دخول المالك قبل استخدامها مع العملاء. لا تضع كلمات مرور أو مفاتيح سرية داخل التطبيق.</Text>
    </>
  );

  const pages = {
    home: renderHome,
    recipes: renderRecipes,
    academy: renderAcademy,
    calculator: renderCalculator,
    admin: renderAdmin,
    subscriptions: renderSubscriptions
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={GREEN} />
      <Header />
      <ScrollView contentContainerStyle={styles.content}>
        {pages[tab]()}
      </ScrollView>
      <View style={styles.nav}>
        {[
          ["home", "الرئيسية", "⌂"],
          ["recipes", "الخلطات", "☕"],
          ["academy", "الأكاديمية", "▤"],
          ["calculator", "الحاسبة", "＋"],
          ["admin", "المدير", "♙"],
          ["subscriptions", "الاشتراك", "ر.س"]
        ].map(([id, label, icon]) => (
          <TouchableOpacity key={id} style={styles.navItem} onPress={() => setTab(id)}>
            <Text style={[styles.navIcon, tab === id && styles.navSelected]}>{icon}</Text>
            <Text style={[styles.navLabel, tab === id && styles.navSelected]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: CREAM },
  header: { backgroundColor: GREEN, paddingHorizontal: 20, paddingTop: 18, paddingBottom: 18, alignItems: "flex-end" },
  brand: { color: "#fff", fontSize: 21, fontWeight: "800", textAlign: "right" },
  tagline: { color: "#E8E1CF", marginTop: 7, fontSize: 13, textAlign: "right" },
  owner: { color: GOLD, marginTop: 10, fontSize: 12, fontWeight: "700" },
  content: { padding: 16, paddingBottom: 28 },
  sectionTitle: { fontSize: 21, fontWeight: "800", color: GREEN, textAlign: "right", marginBottom: 8 },
  muted: { color: "#6C746E", textAlign: "right", lineHeight: 22, fontSize: 13 },
  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", marginTop: 14 },
  tile: { width: "48%", backgroundColor: "#fff", borderRadius: 16, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: "#E8E5DC", alignItems: "flex-end", minHeight: 125 },
  tileIcon: { fontSize: 28, marginBottom: 10 },
  tileTitle: { color: GREEN, fontWeight: "800", fontSize: 15, textAlign: "right" },
  tileDesc: { color: "#788078", fontSize: 11, marginTop: 5, textAlign: "right" },
  panel: { backgroundColor: "#fff", borderRadius: 16, padding: 16, marginTop: 14, borderWidth: 1, borderColor: "#E8E5DC" },
  panelTitle: { color: GREEN, fontSize: 17, fontWeight: "800", textAlign: "right", marginBottom: 8 },
  primaryButton: { backgroundColor: GREEN, borderRadius: 11, padding: 13, alignItems: "center", marginTop: 14 },
  primaryText: { color: "#fff", fontWeight: "800" },
  outlineButton: { borderWidth: 1, borderColor: GREEN, borderRadius: 11, padding: 12, alignItems: "center", marginTop: 10 },
  outlineText: { color: GREEN, fontWeight: "700" },
  chip: { borderRadius: 20, paddingHorizontal: 14, paddingVertical: 9, backgroundColor: "#EAE8E0", marginLeft: 7 },
  chipActive: { backgroundColor: GREEN },
  chipText: { color: GREEN, fontSize: 12, fontWeight: "700" },
  chipTextActive: { color: "#fff" },
  eyebrow: { color: "#A17A2F", textAlign: "right", fontWeight: "800", marginBottom: 8 },
  notice: { color: "#80672F", backgroundColor: "#FBF5E6", padding: 11, borderRadius: 10, marginTop: 12, textAlign: "right", lineHeight: 21, fontSize: 12 },
  lesson: { flexDirection: "row-reverse", alignItems: "center", backgroundColor: "#fff", borderRadius: 13, padding: 13, marginTop: 10, gap: 12 },
  lessonNumber: { backgroundColor: "#E5EEE6", width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  lessonNumberText: { color: GREEN, fontWeight: "900" },
  lessonTitle: { color: GREEN, fontWeight: "800", textAlign: "right", marginBottom: 4 },
  fieldLabel: { textAlign: "right", color: GREEN, fontWeight: "700", marginTop: 16, marginBottom: 8 },
  input: { borderWidth: 1, borderColor: "#DADDD6", borderRadius: 10, padding: 13, textAlign: "right", fontSize: 18, color: GREEN, marginBottom: 14 },
  multiplier: { color: GREEN, fontSize: 34, fontWeight: "900", textAlign: "right", marginTop: 6 },
  price: { color: GREEN, fontSize: 25, fontWeight: "900", textAlign: "right", marginVertical: 8 },
  adminTabs: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7, marginTop: 14 },
  adminTab: { paddingHorizontal: 12, paddingVertical: 9, borderRadius: 20, backgroundColor: "#EAE8E0" },
  adminTabActive: { backgroundColor: GREEN },
  adminTabText: { color: GREEN, fontSize: 12, fontWeight: "700" },
  adminTabTextActive: { color: "#fff" },
  adminItem: { flexDirection: "row-reverse", alignItems: "center", gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "#EEECE5" },
  actionText: { color: "#1B6B4A", fontWeight: "800" },
  deleteText: { color: "#B23B36", fontWeight: "800" },
  multiline: { minHeight: 105, textAlignVertical: "top" },
  categoryChoices: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 5 },
  statRow: { flexDirection: "row", gap: 10, marginTop: 16 },
  statBox: { flex: 1, backgroundColor: "#F6F4EE", borderRadius: 12, padding: 14, alignItems: "center" },
  statNumber: { color: GREEN, fontSize: 18, fontWeight: "900" }
});
